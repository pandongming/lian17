<?php

return [
    'Uid'               => '用户ID',
    'Sign_ip'           => '签到IP',
    'Sign_time'         => '签到时间',
    'Sign_reward'       => '签到基础奖励',
    'Sign_extra_reward' => '连签额外奖励',
    'Max_sign'          => '连签数'
];
