<?php

return [
    'day sign'              => '每日签到',
    'sign rule'             => '签到规则',
    'my sign'               => '我的签到',
    'sign tip'              => '签到可以获得积分哦~',
    'continuous check-in'   => '连续签到',
    'sign in this month'    => '本月签到',
    'extra reward'          => '本月额外奖励',
    'sign time'             => '签到时间',
    'get reward'            => '奖励积分',
    'curr day extra reward' => '额外奖励积分',
    'sign success tip'      => '您已连续签到%s天',
    'close btn'             => '关闭',
    'no login'              => '您还没有登录~',
    'sign failed'           => '签到失败',
    'repeat sign'           => '您已签到，今天无需再签',
    'sign empty'            => '暂时没有您的签到记录',
    'sign reward'           => '签到奖励',
];
