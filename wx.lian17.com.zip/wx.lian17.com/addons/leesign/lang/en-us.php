<?php

return [
    'day sign'              => 'Day Sign',
    'sign rule'             => 'Sign Rule',
    'my sign'               => 'My Sign',
    'sign tip'              => 'Check in to get the integral~',
    'continuous check-in'   => 'Continuous check-in',
    'sign in this month'    => 'Sign in this month',
    'extra reward'          => 'This month extra reward',
    'sign time'             => 'Sign in time',
    'get reward'            => 'Get reward',
    'curr day extra reward' => 'Extra reward',
    'sign success tip'      => 'You have signed in continuously %s days',
    'close btn'             => 'Close',
    'no login'              => 'You haven\'t logged in yet~',
    'sign failed'           => 'Sign in to fail',
    'repeat sign'           => 'You have signed in, there is no need to sign again today',
    'sign empty'            => 'No sign in for your record',
    'sign reward'           => 'Sign reward',
];
