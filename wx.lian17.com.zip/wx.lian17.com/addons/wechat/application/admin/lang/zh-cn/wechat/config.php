<?php

return [
    'name'       => '配置名称',
    'value'      => '配置值',
    'Json key'   => '键',
    'Json value' => '值',
    'createtime' => '创建时间',
    'updatetime' => '更新时间'
];
