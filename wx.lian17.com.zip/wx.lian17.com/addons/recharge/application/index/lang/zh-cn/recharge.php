<?php
return [
    'Recharge'        => '充值余额',
    'Recharge money'  => '充值金额',
    'Other money'     => '其它金额',
    'Pay type'        => '支付方式',
    'Recharge now'    => '立即充值',
    'Balance log'     => '余额日志',
    'Balance'         => '余额',
    'Current balance' => '当前余额',
    'Operate date'    => '操作时间'
];