<?php

return [
    'Userid'      => '创建者',
    'Name'        => '圈子名称',
    'Imgurl'      => '圈子LOGO',
    'Description' => '介绍',
    'Ismenu'      => '审核状态',
    'Status'      => '审核状态',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间'
];
