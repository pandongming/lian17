<?php

return [
    'Keywords'    => '关键字',
    'Description' => '描述',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Weigh'       => '权重',
    'Status'      => '状态'
];
