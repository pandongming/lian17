<?php

return [
    'Share_out_num' => '积分百分比',
    'Remark'        => '备注'
];
