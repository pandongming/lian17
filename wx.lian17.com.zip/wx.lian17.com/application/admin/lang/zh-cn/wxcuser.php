<?php

return [
    'Openid'       => 'OpenId',
    'Nickname'     => '昵称',
    'Sex'          => '性别',
    'Avatar'       => '头像',
    'Email'        => '邮箱',
    'Moblie'       => '手机',
    'Company_name' => '公司名称',
    'User_name'    => '真实姓名',
    'Invited_code' => '邀请码',
    'Type'         => '0->个人用户, 1->企业用户',
    'Father_id'    => '父级',
    'Grandpa_id'   => '祖级',
    'Userfee'      => '抵用系数',
    'Score'        => '积分',
    'Createtime'   => '关注时间',
    'Team.userid'  => '创建者'
];
