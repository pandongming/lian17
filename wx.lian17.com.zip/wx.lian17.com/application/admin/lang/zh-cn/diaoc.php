<?php

return [
    'Hyname'      => '所属行业名称',
    'Station'     => '岗位名称',
    'Job'         => '职位名称',
    'Mobile'      => '电话',
    'Skillname'   => '技能名称',
    'Uname'       => '关系调查名称',
    'Qyname'      => '企业名称',
    'Price'       => '预算金额',
    'Typename'    => '调查类型名称',
    'Description' => '需求说明',
    'Hyid'        => '行业ID',
    'Needname'    => '需求人名称'
];
